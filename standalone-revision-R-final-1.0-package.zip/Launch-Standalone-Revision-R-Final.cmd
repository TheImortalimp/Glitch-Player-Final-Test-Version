@echo off
setlocal
set APP=%~dp0app\StandaloneRevisionRFinal.exe
if not exist "%APP%" (
  echo Application files are missing: %APP%
  exit /b 1
)
start "" "%APP%"
