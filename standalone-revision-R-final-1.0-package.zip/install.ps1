﻿param(
        [string]$InstallRoot = (Join-Path ([Environment]::GetFolderPath("Desktop")) "standalone-revision-R-final-1.0")
)

$ErrorActionPreference = "Stop"

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null

$sourceRoot = Split-Path -Parent $PSCommandPath
$files = @(
    "AUTHORS.TXT",
    "build-manifest.json",
    "Launch-Standalone-Revision-R-Final.cmd"
)

foreach ($file in $files) {
    $src = Join-Path $sourceRoot $file
    if (Test-Path $src) {
        Copy-Item -Path $src -Destination (Join-Path $InstallRoot $file) -Force
    }
}

$webuiTarget = Join-Path $InstallRoot "webui"
New-Item -ItemType Directory -Force -Path $webuiTarget | Out-Null
Copy-Item -Path (Join-Path $sourceRoot "webui\*") -Destination $webuiTarget -Recurse -Force

$appTarget = Join-Path $InstallRoot "app"
New-Item -ItemType Directory -Force -Path $appTarget | Out-Null
Copy-Item -Path (Join-Path $sourceRoot "app\*") -Destination $appTarget -Recurse -Force

Write-Host "Installed to: $InstallRoot"
