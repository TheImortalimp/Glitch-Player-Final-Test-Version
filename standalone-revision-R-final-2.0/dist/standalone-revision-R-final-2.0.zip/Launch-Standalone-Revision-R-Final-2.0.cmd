@echo off
setlocal
set "ROOT=%~dp0"
set "WEBUI=%ROOT%webui"
set "URL=http://127.0.0.1:18180/glitch-canvas.html"

where py >nul 2>nul
if not errorlevel 1 (
  start "Glitch Canvas HTTP Server" /min py -m http.server 18180 --bind 127.0.0.1 --directory "%WEBUI%"
  start "Standalone Revision R Final 2.0" "%URL%"
  exit /b 0
)

where python >nul 2>nul
if not errorlevel 1 (
  start "Glitch Canvas HTTP Server" /min python -m http.server 18180 --bind 127.0.0.1 --directory "%WEBUI%"
  start "Standalone Revision R Final 2.0" "%URL%"
  exit /b 0
)

echo Python was not found. Opening local mode; YouTube playback needs localhost.
start "Standalone Revision R Final 2.0" "%WEBUI%\glitch-canvas.html"
endlocal