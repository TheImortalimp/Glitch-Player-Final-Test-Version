# Standalone Revision R Final 3.0

Source release for the Glitch Canvas standalone player.

This revision carries forward the Revision R player shell from 3.0 and 2.0
and imports the current `glitch-canvas.html` and `glitch-canvas.css` palette,
built on today's effects-scripting pass:

- Smoother, less erratic continual-randomization sliders (no more hard 0%/100%
  flips by default, effects stay within their own designed ranges)
- Occasional graceful full-strength climbs and elevated ambient baselines
- Modest, direction-correct "mirror burst" (every unlocked slider inverts
  together around 50%)
- Trigger buttons now always produce a visible pulse even at 0% opacity,
  still capped at 5 triggers per 5 seconds
- Higher-resolution (DPR-aware) glitch canvas, dynamic V-Sync sharpen kernel,
  smoother sub-pixel V-Sync scan motion, and shared Ghost Protocol/V-Sync/AI
  Warp hue confluence

## Run

Use `Launch-Standalone-Revision-R-Final-3.0.cmd`. It starts the actual
`app/StandaloneRevisionRFinal.exe` WebView2 shell, which hosts the UI in a
standalone application window. YouTube iframe playback is handled by the
embedded shell origin; no standard browser or Python server is used.

## Source layout

- `webui/glitch-canvas.html`: full player UI, palette, and JavaScript engine
- `webui/glitch-canvas.css`: visual system and responsive control styling
- `Launch-Standalone-Revision-R-Final-3.0.cmd`: visible Windows launcher
- `app/StandaloneRevisionRFinal.exe`: standalone WebView2 application host
- `Start-Standalone-Revision-R-Final-3.0.ps1`: starts the shell at 1280x720
- `install.ps1`: copies this source release to a selected output directory

## Build status

The 3.0 package reuses the verified Revision R WebView2 host from 2.0 and
carries forward its web UI payload, updated with this session's effects
scripting changes. The existing 2.0 and 1.0 releases remain untouched.

The default launcher opens the shell window at 1280x720 so controls remain
inside the physical display area. Press Alt+Enter to switch between windowed
and fullscreen modes.
