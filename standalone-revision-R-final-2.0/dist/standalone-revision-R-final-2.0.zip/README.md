# Standalone Revision R Final 2.0

Source release for the Glitch Canvas standalone player.

This revision keeps the Revision R player elements and imports the current
`glitch-canvas.html` and `glitch-canvas.css` palette, including the expanded
effect definitions, Ghost Protocol, V-Sync Scan, AI Video Warp, presets,
local MP3/MP4 playback, YouTube URL validation, and the visual canvas engine.

## Run

Use `Launch-Standalone-Revision-R-Final-2.0.cmd`. The launcher starts a local
HTTP server for `webui/` when Python is available, then opens the player at
`http://127.0.0.1:18180/glitch-canvas.html`. YouTube iframe playback requires
an HTTP origin; local MP3/MP4 playback can also be opened directly from the
HTML file.

## Source layout

- `webui/glitch-canvas.html`: full player UI, palette, and JavaScript engine
- `webui/glitch-canvas.css`: visual system and responsive control styling
- `Launch-Standalone-Revision-R-Final-2.0.cmd`: visible Windows launcher
- `install.ps1`: copies this source release to a selected output directory

The incoming source was staged from the local `glitch-canvas.html` and
`glitch-canvas.css` files in the release workspace. The packaged Revision R
1.0 artifacts remain separate under the parent release directory.

## Build status

This is a source-first 2.0 release. The existing 1.0 binary is not replaced
until the new web UI has been smoke-tested with YouTube, MP4, and MP3 inputs.